# 🛰️ FedSat AI: Federated Learning for Satellite Edge Networks

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Research](https://img.shields.io/badge/level-research-brightgreen.svg)]()

> A simulation framework for **Federated Learning across satellite edge networks**, enabling privacy-preserving collaborative model training without sharing raw data between nodes.

---

## 📖 Abstract

FedSat AI simulates a constellation of low-earth-orbit (LEO) satellites that collaboratively train a machine learning model using the **Federated Averaging (FedAvg)** algorithm. Each satellite holds a private, non-IID local dataset (representing sensor readings, telemetry, or imagery classifications). Only model weight updates — never raw data — are transmitted to a central ground station aggregator.

This project demonstrates:
- Federated learning convergence under heterogeneous (non-IID) data distributions
- Communication efficiency vs. model accuracy trade-offs
- The effect of communication delay on training dynamics
- Comparative analysis between federated and centralized learning paradigms

---

## 🏗️ Architecture

```
FedSat-AI/
├── README.md                        # This file
├── requirements.txt                 # Python dependencies
├── main.py                          # Entry point — full pipeline
├── data/                            # Generated datasets (auto-created)
├── src/
│   ├── satellite_client.py          # Satellite node simulator
│   ├── federated_server.py          # Central aggregation server
│   ├── data_generator.py            # Non-IID dataset generator
│   ├── model.py                     # Neural network architectures
│   ├── fedavg.py                    # FedAvg aggregation algorithm
│   ├── training.py                  # Local training loop
│   ├── evaluation.py                # Model evaluation & metrics
│   └── visualization.py             # Plots & analysis charts
├── scripts/
│   └── run_federated_training.py    # Standalone experiment runner
├── results/                         # Output plots and metrics (auto-created)
└── tests/
    ├── test_satellite_client.py
    ├── test_fedavg.py
    ├── test_data_generator.py
    ├── test_model.py
    └── test_evaluation.py
```

---

## 🚀 Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/yourname/FedSat-AI.git
cd FedSat-AI
pip install -r requirements.txt
```

### 2. Run Full Pipeline

```bash
python main.py
```

### 3. Run with Custom Configuration

```bash
python scripts/run_federated_training.py \
  --num_satellites 10 \
  --rounds 30 \
  --local_epochs 5 \
  --non_iid_alpha 0.5 \
  --compare_centralized
```

### 4. Run Tests

```bash
python -m pytest tests/ -v
```

---

## ⚙️ Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_satellites` | `6` | Number of satellite clients |
| `rounds` | `20` | Global federated rounds |
| `local_epochs` | `3` | Local training epochs per round |
| `local_batch_size` | `32` | Mini-batch size for local SGD |
| `learning_rate` | `0.01` | Local SGD learning rate |
| `non_iid_alpha` | `0.5` | Dirichlet α for non-IID split (lower = more heterogeneous) |
| `fraction_fit` | `1.0` | Fraction of satellites sampled per round |
| `comm_delay_min` | `0.1` | Min simulated communication delay (s) |
| `comm_delay_max` | `2.0` | Max simulated communication delay (s) |
| `dataset` | `synthetic` | Dataset type: `synthetic` or `mnist` |

---

## 🧪 Federated Learning Algorithm

### FedAvg (McMahan et al., 2017)

```
Server initializes global model w₀
For each round t = 1, ..., T:
    Select subset S_t of satellites
    Broadcast w_t to all s ∈ S_t
    For each satellite s ∈ S_t (in parallel):
        w_{t+1}^s ← LocalSGD(w_t, dataset_s, E, B)
    w_{t+1} ← Σ (n_s / n) · w_{t+1}^s   ← weighted average
```

Where:
- `E` = local epochs
- `B` = local batch size  
- `n_s` = number of samples on satellite s
- `n` = total samples across selected satellites

---

## 📊 Non-IID Data Distribution

Each satellite's data is drawn using a **Dirichlet distribution** with concentration parameter `α`:

- `α → ∞`: IID (uniform class distribution)
- `α = 1.0`: Moderate heterogeneity
- `α = 0.1`: Extreme non-IID (each satellite dominates 1–2 classes)

This models realistic satellite scenarios where different orbital planes observe different geographic regions with distinct class distributions.

---

## 📈 Results & Visualizations

Running the full pipeline generates:

| Output | Description |
|--------|-------------|
| `results/federated_accuracy.png` | Global accuracy per round |
| `results/federated_loss.png` | Global loss per round |
| `results/per_satellite_loss.png` | Per-satellite local loss curves |
| `results/comparison.png` | Federated vs. centralized comparison |
| `results/data_distribution.png` | Non-IID data distribution heatmap |
| `results/communication_delay.png` | Communication delay distribution |
| `results/metrics.json` | All numeric metrics (JSON) |

---

## 🔬 Research Extensions

This framework supports exploration of:

- **FedProx**: Add proximal term to local objective
- **SCAFFOLD**: Variance reduction via control variates
- **Clustered FL**: Group satellites by data similarity
- **Asynchronous FL**: Handle stragglers & variable delays
- **Differential Privacy**: Add Gaussian noise to gradients
- **Compression**: Top-k sparsification of updates

---

## 📚 References

1. McMahan, H. B., et al. (2017). *Communication-Efficient Learning of Deep Networks from Decentralized Data*. AISTATS.
2. Li, T., et al. (2020). *Federated Learning: Challenges, Methods, and Future Directions*. IEEE Signal Processing Magazine.
3. Hsieh, K., et al. (2020). *Quagmire: Non-IID Data in Federated Learning*. ICML Workshop.
4. Del Portillo, I., et al. (2019). *A technical comparison of three LEO satellite constellation systems*. Acta Astronautica.

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

## 👤 Author

Built as a research-grade simulation framework for federated learning in space edge computing environments.
