"""
main.py
-------
FedSat AI — Full end-to-end pipeline entry point.

Usage
-----
    python main.py                         # defaults
    python main.py --num_satellites 8 --rounds 25 --non_iid_alpha 0.3

Pipeline
--------
1.  Generate synthetic dataset
2.  Partition data non-IID across satellites (Dirichlet)
3.  Build model, satellite clients, server
4.  Run federated training (FedAvg)
5.  Train centralised baseline for comparison
6.  Evaluate final global model
7.  Produce all visualisation figures
8.  Print & save summary metrics
"""

import os
import sys
import json
import copy
import argparse
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

# ── local imports ─────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))

from src.data_generator    import (generate_synthetic_dataset,
                                    partition_data_dirichlet,
                                    build_data_loaders,
                                    compute_class_distribution,
                                    partition_summary)
from src.model             import get_model, model_size_kb, count_parameters
from src.satellite_client  import build_satellite_clients
from src.federated_server  import FederatedServer
from src.training          import centralized_train, evaluate_local
from src.evaluation        import (evaluate_model, final_metrics_summary,
                                    communication_cost_kb, compute_fairness_metric,
                                    convergence_round)
from src.visualization     import (plot_accuracy_curve, plot_loss_curves,
                                    plot_per_satellite_loss,
                                    plot_federated_vs_centralized,
                                    plot_data_distribution,
                                    plot_communication_delays,
                                    plot_update_norms,
                                    plot_summary_dashboard)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="FedSat AI — Federated Learning for Satellite Edge Networks"
    )
    p.add_argument("--num_satellites",   type=int,   default=6,     help="Number of satellite clients")
    p.add_argument("--rounds",           type=int,   default=20,    help="Federated communication rounds")
    p.add_argument("--local_epochs",     type=int,   default=3,     help="Local SGD epochs per round")
    p.add_argument("--batch_size",       type=int,   default=32,    help="Local mini-batch size")
    p.add_argument("--lr",               type=float, default=0.01,  help="Local learning rate")
    p.add_argument("--non_iid_alpha",    type=float, default=0.5,   help="Dirichlet α (lower=more non-IID)")
    p.add_argument("--n_samples",        type=int,   default=6000,  help="Total dataset size")
    p.add_argument("--n_features",       type=int,   default=20,    help="Feature dimension")
    p.add_argument("--n_classes",        type=int,   default=10,    help="Number of classes")
    p.add_argument("--hidden_dim",       type=int,   default=128,   help="MLP hidden layer width")
    p.add_argument("--fraction_fit",     type=float, default=1.0,   help="Fraction of clients per round")
    p.add_argument("--comm_delay_min",   type=float, default=0.1,   help="Min comm delay (s)")
    p.add_argument("--comm_delay_max",   type=float, default=2.0,   help="Max comm delay (s)")
    p.add_argument("--centralized_epochs", type=int, default=20,    help="Epochs for centralised baseline")
    p.add_argument("--no_comparison",    action="store_true",       help="Skip centralised comparison")
    p.add_argument("--results_dir",      type=str,   default="results", help="Output directory")
    p.add_argument("--seed",             type=int,   default=42,    help="Global random seed")
    p.add_argument("--device",           type=str,   default="auto",help="cpu | cuda | auto")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def setup_device(choice: str) -> torch.device:
    if choice == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(choice)


def set_seed(seed: int) -> None:
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_test_loader(
    X: np.ndarray, y: np.ndarray, batch_size: int = 256
) -> DataLoader:
    X_t = torch.tensor(X, dtype=torch.float32)
    y_t = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(X_t, y_t), batch_size=batch_size,
                      shuffle=False, drop_last=False)


def make_centralised_train_loader(
    X: np.ndarray, y: np.ndarray, batch_size: int = 64
) -> DataLoader:
    X_t = torch.tensor(X, dtype=torch.float32)
    y_t = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(X_t, y_t), batch_size=batch_size,
                      shuffle=True, drop_last=False)


def banner(msg: str) -> None:
    print(f"\n{'─'*60}")
    print(f"  {msg}")
    print(f"{'─'*60}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    device = setup_device(args.device)
    os.makedirs(args.results_dir, exist_ok=True)
    os.makedirs("data", exist_ok=True)

    t_total_start = time.perf_counter()

    # ── 1. Dataset ────────────────────────────────────────────────────────────
    banner("Step 1 / 7 — Generating Synthetic Dataset")
    # Split into 80% train, 20% test
    n_train = int(args.n_samples * 0.8)
    n_test  = args.n_samples - n_train

    X_all, y_all = generate_synthetic_dataset(
        n_samples=args.n_samples,
        n_features=args.n_features,
        n_classes=args.n_classes,
        random_state=args.seed,
        save_path="data/full_dataset.csv",
    )
    X_train, y_train = X_all[:n_train], y_all[:n_train]
    X_test,  y_test  = X_all[n_train:], y_all[n_train:]

    print(f"  Train: {n_train} samples | Test: {n_test} samples")
    print(f"  Features: {args.n_features} | Classes: {args.n_classes}")

    # ── 2. Non-IID partitioning ───────────────────────────────────────────────
    banner("Step 2 / 7 — Partitioning Data (Non-IID, Dirichlet α={:.2f})".format(
        args.non_iid_alpha))

    client_indices = partition_data_dirichlet(
        y=y_train,
        num_clients=args.num_satellites,
        alpha=args.non_iid_alpha,
        random_state=args.seed,
    )
    sample_counts = {cid: len(idx) for cid, idx in client_indices.items()}

    summary_df = partition_summary(client_indices, y_train, args.n_classes)
    print(summary_df.to_string())
    summary_df.to_csv(os.path.join(args.results_dir, "partition_summary.csv"))

    client_loaders = build_data_loaders(
        X_train, y_train, client_indices, batch_size=args.batch_size
    )
    test_loader  = make_test_loader(X_test, y_test)

    # ── 3. Model & clients ────────────────────────────────────────────────────
    banner("Step 3 / 7 — Building Model & Satellite Clients")

    def model_factory():
        return get_model("mlp", input_dim=args.n_features,
                         num_classes=args.n_classes,
                         hidden_dim=args.hidden_dim)

    global_model  = model_factory()
    total_params, trainable_params = count_parameters(global_model)
    size_kb = model_size_kb(global_model)
    print(f"  Model       : MLP ({args.n_features}→{args.hidden_dim}→{args.n_classes})")
    print(f"  Parameters  : {total_params:,} ({trainable_params:,} trainable)")
    print(f"  Model size  : {size_kb:.2f} KB")

    clients = build_satellite_clients(
        num_clients=args.num_satellites,
        model_factory=model_factory,
        data_loaders=client_loaders,
        sample_counts=sample_counts,
        local_epochs=args.local_epochs,
        lr=args.lr,
        comm_delay_min=args.comm_delay_min,
        comm_delay_max=args.comm_delay_max,
        device=device,
        seed=args.seed,
    )
    for c in clients:
        print(f"  {c}")

    # ── 4. Federated training ─────────────────────────────────────────────────
    banner("Step 4 / 7 — Federated Training (FedAvg)")
    server = FederatedServer(
        global_model=global_model,
        test_loader=test_loader,
        device=device,
        fraction_fit=args.fraction_fit,
        seed=args.seed,
        verbose=True,
    )
    fed_history = server.fit(clients, num_rounds=args.rounds)

    fed_accs   = server.get_test_accuracies()
    fed_losses = server.get_test_losses()
    fed_client_losses = server.get_client_losses()
    fed_delays = server.get_comm_delays()
    fed_norms  = server.get_update_norms()

    # ── 5. Centralised baseline ───────────────────────────────────────────────
    cen_history = None
    if not args.no_comparison:
        banner("Step 5 / 7 — Centralised Baseline Training")
        cen_model  = model_factory().to(device)
        cen_loader = make_centralised_train_loader(X_train, y_train)
        cen_history = centralized_train(
            model=cen_model,
            train_loader=cen_loader,
            test_loader=test_loader,
            epochs=args.centralized_epochs,
            lr=args.lr,
            device=device,
            verbose=True,
        )
    else:
        banner("Step 5 / 7 — Centralised Baseline (skipped)")

    # ── 6. Evaluation ─────────────────────────────────────────────────────────
    banner("Step 6 / 7 — Final Evaluation")
    final_metrics = evaluate_model(server.global_model, test_loader, device,
                                   num_classes=args.n_classes)
    print(f"  Final global model metrics:")
    for k, v in final_metrics.items():
        print(f"    {k:<20s}: {v:.4f}")

    # Per-client accuracy (fairness)
    client_final_accs = []
    for c in clients:
        _, acc = c.evaluate()
        client_final_accs.append(acc)
    fairness = compute_fairness_metric(client_final_accs)
    print(f"\n  Fairness metrics (client accuracy distribution):")
    for k, v in fairness.items():
        print(f"    {k:<20s}: {v:.4f}")

    comm_cost = communication_cost_kb(size_kb, args.num_satellites,
                                      args.rounds, args.fraction_fit)
    print(f"\n  Communication cost:")
    for k, v in comm_cost.items():
        print(f"    {k:<20s}: {v:.2f} KB")

    # Summary JSON
    summary = final_metrics_summary(
        fed_history=fed_history,
        centralized_history=cen_history,
        num_clients=args.num_satellites,
        num_rounds=args.rounds,
        model_size_kb=size_kb,
    )
    summary["final_eval"]    = final_metrics
    summary["fairness"]      = fairness
    summary["comm_cost_kb"]  = comm_cost

    metrics_path = os.path.join(args.results_dir, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(summary, f, indent=2, default=str)
    print(f"\n  Metrics saved → {metrics_path}")

    # ── 7. Visualisations ─────────────────────────────────────────────────────
    banner("Step 7 / 7 — Generating Visualisations")

    R = args.results_dir

    plot_accuracy_curve(
        fed_accs,
        output_path=os.path.join(R, "federated_accuracy.png")
    )

    plot_loss_curves(
        fed_losses, fed_client_losses,
        output_path=os.path.join(R, "federated_loss.png")
    )

    # Per-satellite loss history
    per_sat_losses = {c.client_id: c.round_losses for c in clients}
    plot_per_satellite_loss(
        per_sat_losses,
        output_path=os.path.join(R, "per_satellite_loss.png")
    )

    # Data distribution
    dist_matrix = compute_class_distribution(client_indices, y_train, args.n_classes)
    plot_data_distribution(
        dist_matrix,
        output_path=os.path.join(R, "data_distribution.png")
    )

    # Communication delays
    all_delays = {c.client_id: c.round_delays for c in clients}
    plot_communication_delays(
        fed_delays, all_delays,
        output_path=os.path.join(R, "communication_delay.png")
    )

    plot_update_norms(
        fed_norms,
        output_path=os.path.join(R, "update_norms.png")
    )

    if cen_history is not None:
        plot_federated_vs_centralized(
            fed_accs, cen_history["test_acc"],
            output_path=os.path.join(R, "comparison.png")
        )

    plot_summary_dashboard(
        fed_accuracies=fed_accs,
        fed_losses=fed_losses,
        cen_accuracies=cen_history["test_acc"] if cen_history else None,
        cen_losses=cen_history["test_loss"]    if cen_history else None,
        client_losses=fed_client_losses,
        delays=fed_delays,
        update_norms=fed_norms,
        distribution=dist_matrix,
        output_path=os.path.join(R, "summary_dashboard.png")
    )

    # ── Summary print ─────────────────────────────────────────────────────────
    elapsed = time.perf_counter() - t_total_start
    best    = server.best_round()
    conv80  = convergence_round(fed_accs, 0.80)

    print(f"\n{'═'*60}")
    print(f"  🛰  FedSat AI — Pipeline Complete  ({elapsed:.1f}s total)")
    print(f"{'═'*60}")
    print(f"  Satellites          : {args.num_satellites}")
    print(f"  Rounds              : {args.rounds}")
    print(f"  Best federated acc  : {best.global_test_acc:.4f} (round {best.round_num})")
    print(f"  Final federated acc : {fed_accs[-1]:.4f}")
    if cen_history:
        print(f"  Final centralized   : {cen_history['test_acc'][-1]:.4f}")
        print(f"  Accuracy gap        : {cen_history['test_acc'][-1] - fed_accs[-1]:.4f}")
    print(f"  Convergence (≥0.80) : round {conv80 or 'N/A'}")
    print(f"  Jain's fairness idx : {fairness['jains_index']:.4f}")
    print(f"  Results saved in    : {os.path.abspath(R)}/")
    print(f"{'═'*60}\n")


if __name__ == "__main__":
    main()
