"""
tests/test_model.py
--------------------
Unit tests for src/model.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import torch
import torch.nn as nn
import numpy as np

from src.model import (
    MLP, CNN, get_model, model_size_kb,
    count_parameters, copy_model_weights, model_l2_norm,
)


class TestMLP:

    def test_output_shape(self):
        model = MLP(input_dim=20, hidden_dim=64, num_classes=10)
        x = torch.randn(16, 20)
        out = model(x)
        assert out.shape == (16, 10)

    def test_different_batch_sizes(self):
        model = MLP(input_dim=15, num_classes=5)
        for bs in [1, 4, 32, 128]:
            out = model(torch.randn(bs, 15))
            assert out.shape == (bs, 5)

    def test_no_nan_forward(self):
        model = MLP(input_dim=20, num_classes=8)
        x = torch.randn(32, 20)
        out = model(x)
        assert not torch.isnan(out).any()

    def test_parameters_exist(self):
        model = MLP(input_dim=10, hidden_dim=32, num_classes=4)
        total, trainable = count_parameters(model)
        assert total > 0
        assert trainable == total

    def test_backward_pass(self):
        model = MLP(input_dim=10, num_classes=5)
        x = torch.randn(8, 10)
        y = torch.randint(0, 5, (8,))
        loss = nn.CrossEntropyLoss()(model(x), y)
        loss.backward()
        for p in model.parameters():
            assert p.grad is not None


class TestCNN:

    def test_output_shape_mnist(self):
        model = CNN(in_channels=1, num_classes=10)
        x = torch.randn(4, 1, 28, 28)
        out = model(x)
        assert out.shape == (4, 10)

    def test_no_nan_forward(self):
        model = CNN(in_channels=1, num_classes=10)
        x = torch.randn(8, 1, 28, 28)
        out = model(x)
        assert not torch.isnan(out).any()


class TestGetModel:

    def test_returns_mlp(self):
        m = get_model("mlp", input_dim=20, num_classes=10)
        assert isinstance(m, MLP)

    def test_returns_cnn(self):
        m = get_model("cnn", num_classes=10)
        assert isinstance(m, CNN)

    def test_invalid_type_raises(self):
        with pytest.raises(ValueError):
            get_model("transformer")


class TestModelUtilities:

    def test_model_size_kb_positive(self):
        m = MLP(input_dim=20, hidden_dim=64, num_classes=5)
        assert model_size_kb(m) > 0

    def test_copy_model_weights(self):
        src = MLP(input_dim=10, num_classes=4)
        dst = MLP(input_dim=10, num_classes=4)
        # Modify dst
        with torch.no_grad():
            for p in dst.parameters():
                p.fill_(999.0)
        copy_model_weights(src, dst)
        for ps, pd in zip(src.parameters(), dst.parameters()):
            assert torch.allclose(ps, pd)

    def test_model_l2_norm_positive(self):
        m = MLP(input_dim=10, num_classes=4)
        norm = model_l2_norm(m)
        assert norm > 0

    def test_count_parameters(self):
        m = MLP(input_dim=5, hidden_dim=8, num_classes=3)
        total, trainable = count_parameters(m)
        assert total == trainable
        assert total > 0
