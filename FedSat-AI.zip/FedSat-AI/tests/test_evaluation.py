"""
tests/test_evaluation.py
------------------------
Unit tests for src/evaluation.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import torch
import numpy as np
from torch.utils.data import DataLoader, TensorDataset

from src.model      import MLP
from src.evaluation import (
    evaluate_model,
    compute_confusion_matrix,
    classification_report_df,
    convergence_round,
    communication_cost_kb,
    compute_fairness_metric,
    final_metrics_summary,
)
from src.federated_server import RoundResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_test_loader(n: int = 200, n_feat: int = 10, n_classes: int = 5) -> DataLoader:
    X = torch.randn(n, n_feat)
    y = torch.randint(0, n_classes, (n,))
    return DataLoader(TensorDataset(X, y), batch_size=32, shuffle=False)


def make_model(n_feat: int = 10, n_classes: int = 5) -> MLP:
    return MLP(input_dim=n_feat, hidden_dim=32, num_classes=n_classes)


# ---------------------------------------------------------------------------
# evaluate_model
# ---------------------------------------------------------------------------

class TestEvaluateModel:

    def test_keys_present(self):
        model  = make_model()
        loader = make_test_loader()
        result = evaluate_model(model, loader)
        for k in ["loss", "accuracy", "macro_f1", "weighted_f1"]:
            assert k in result

    def test_accuracy_in_range(self):
        model  = make_model()
        loader = make_test_loader()
        result = evaluate_model(model, loader)
        assert 0.0 <= result["accuracy"] <= 1.0

    def test_loss_positive(self):
        model  = make_model()
        loader = make_test_loader()
        result = evaluate_model(model, loader)
        assert result["loss"] > 0

    def test_perfect_accuracy(self):
        """A model that always predicts class 0 on a single-class dataset."""
        import torch.nn as nn
        n_feat, n_cls = 5, 3
        X = torch.randn(50, n_feat)
        y = torch.zeros(50, dtype=torch.long)
        loader = DataLoader(TensorDataset(X, y), batch_size=16)

        class AlwaysZero(nn.Module):
            def forward(self, x):
                out = torch.zeros(x.size(0), 3)
                out[:, 0] = 100.0
                return out

        result = evaluate_model(AlwaysZero(), loader)
        assert result["accuracy"] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# compute_confusion_matrix
# ---------------------------------------------------------------------------

class TestComputeConfusionMatrix:

    def test_shape(self):
        model  = make_model(n_classes=5)
        loader = make_test_loader(n_classes=5)
        cm = compute_confusion_matrix(model, loader, num_classes=5)
        assert cm.shape == (5, 5)

    def test_non_negative(self):
        model  = make_model(n_classes=4)
        loader = make_test_loader(n_classes=4)
        cm = compute_confusion_matrix(model, loader, num_classes=4)
        assert (cm >= 0).all()

    def test_row_sums_equal_support(self):
        model  = make_model(n_classes=3)
        loader = make_test_loader(n=90, n_classes=3)
        cm = compute_confusion_matrix(model, loader, num_classes=3)
        assert cm.sum() == 90


# ---------------------------------------------------------------------------
# classification_report_df
# ---------------------------------------------------------------------------

class TestClassificationReportDf:

    def test_returns_dataframe(self):
        import pandas as pd
        model  = make_model(n_classes=5)
        loader = make_test_loader(n_classes=5)
        df = classification_report_df(model, loader)
        assert isinstance(df, pd.DataFrame)

    def test_has_correct_columns(self):
        model  = make_model(n_classes=5)
        loader = make_test_loader(n_classes=5)
        df = classification_report_df(model, loader)
        for col in ["precision", "recall", "f1-score", "support"]:
            assert col in df.columns


# ---------------------------------------------------------------------------
# convergence_round
# ---------------------------------------------------------------------------

class TestConvergenceRound:

    def test_finds_correct_round(self):
        accs = [0.5, 0.7, 0.82, 0.85, 0.90]
        assert convergence_round(accs, 0.80) == 3

    def test_returns_none_if_never_reached(self):
        accs = [0.5, 0.6, 0.7]
        assert convergence_round(accs, 0.95) is None

    def test_first_round_counts(self):
        accs = [0.95, 0.96, 0.97]
        assert convergence_round(accs, 0.90) == 1


# ---------------------------------------------------------------------------
# communication_cost_kb
# ---------------------------------------------------------------------------

class TestCommunicationCostKb:

    def test_positive_values(self):
        result = communication_cost_kb(model_size_kb=50.0, num_clients=6,
                                       num_rounds=20, fraction_fit=1.0)
        for v in result.values():
            assert v > 0

    def test_total_equals_up_plus_down(self):
        result = communication_cost_kb(100.0, 5, 10, 0.5)
        assert abs(result["total_kb"] - result["uplink_kb"] - result["downlink_kb"]) < 1e-6


# ---------------------------------------------------------------------------
# compute_fairness_metric
# ---------------------------------------------------------------------------

class TestComputeFairnessMetric:

    def test_keys_present(self):
        fm = compute_fairness_metric([0.8, 0.85, 0.7, 0.9])
        for k in ["mean_acc", "std_acc", "var_acc", "gap", "jains_index"]:
            assert k in fm

    def test_perfect_fairness_jain(self):
        # All equal → Jain's index = 1.0
        fm = compute_fairness_metric([0.8, 0.8, 0.8, 0.8])
        assert fm["jains_index"] == pytest.approx(1.0, abs=1e-5)

    def test_zero_gap_for_equal_accs(self):
        fm = compute_fairness_metric([0.7, 0.7, 0.7])
        assert fm["gap"] == pytest.approx(0.0, abs=1e-6)


# ---------------------------------------------------------------------------
# final_metrics_summary
# ---------------------------------------------------------------------------

class TestFinalMetricsSummary:

    def _make_round_result(self, rnd: int, acc: float) -> RoundResult:
        return RoundResult(
            round_num=rnd,
            selected_clients=[0, 1],
            global_test_loss=1.0 - acc,
            global_test_acc=acc,
            mean_client_loss=0.5,
            mean_client_acc=acc,
            mean_update_norm=0.1,
            mean_comm_delay_s=0.5,
            max_comm_delay_s=1.0,
            num_samples_used=500,
            wall_time_s=1.0,
        )

    def test_returns_dict(self):
        history = [self._make_round_result(i, 0.5 + i * 0.02) for i in range(10)]
        summary = final_metrics_summary(history, num_clients=5, num_rounds=10)
        assert isinstance(summary, dict)
        assert "federated" in summary

    def test_best_acc_correct(self):
        accs    = [0.6, 0.7, 0.8, 0.75]
        history = [self._make_round_result(i+1, accs[i]) for i in range(4)]
        summary = final_metrics_summary(history)
        assert summary["federated"]["best_test_acc"] == pytest.approx(0.8)
