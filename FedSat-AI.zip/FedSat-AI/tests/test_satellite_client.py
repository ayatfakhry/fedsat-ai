"""
tests/test_satellite_client.py
-------------------------------
Unit tests for src/satellite_client.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import copy
import pytest
import torch
import numpy as np
from torch.utils.data import DataLoader, TensorDataset

from src.model            import MLP
from src.satellite_client import (
    SatelliteClient, SatelliteOrbit, CommChannel, build_satellite_clients
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_loader(n: int = 100, n_feat: int = 10, n_classes: int = 5,
                batch_size: int = 16) -> DataLoader:
    X = torch.randn(n, n_feat)
    y = torch.randint(0, n_classes, (n,))
    return DataLoader(TensorDataset(X, y), batch_size=batch_size, shuffle=True)


def make_client(cid: int = 0, n_feat: int = 10, n_classes: int = 5,
                n_samples: int = 100) -> SatelliteClient:
    model  = MLP(input_dim=n_feat, hidden_dim=32, num_classes=n_classes)
    loader = make_loader(n=n_samples, n_feat=n_feat, n_classes=n_classes)
    return SatelliteClient(
        client_id=cid,
        model=model,
        data_loader=loader,
        num_samples=n_samples,
        local_epochs=2,
        lr=0.01,
        device=torch.device("cpu"),
    )


# ---------------------------------------------------------------------------
# SatelliteOrbit
# ---------------------------------------------------------------------------

class TestSatelliteOrbit:

    def test_default_altitude(self):
        o = SatelliteOrbit(0)
        assert o.altitude_km == 550.0

    def test_distance_positive(self):
        o = SatelliteOrbit(1)
        assert o.ground_station_distance_km > 0

    def test_longitude_in_range(self):
        o = SatelliteOrbit(42)
        assert 0.0 <= o.longitude_deg <= 360.0


# ---------------------------------------------------------------------------
# CommChannel
# ---------------------------------------------------------------------------

class TestCommChannel:

    def test_delay_within_bounds(self):
        ch = CommChannel(min_delay_s=0.5, max_delay_s=1.5, seed=0)
        for _ in range(20):
            d = ch.simulate_delay()
            assert d >= 0.5

    def test_delay_log_grows(self):
        ch = CommChannel(seed=1)
        ch.simulate_delay()
        ch.simulate_delay()
        assert len(ch.delay_log) == 2

    def test_mean_delay_reasonable(self):
        ch = CommChannel(min_delay_s=1.0, max_delay_s=2.0, seed=7)
        for _ in range(100):
            ch.simulate_delay()
        assert 1.0 <= ch.mean_delay() <= 2.5

    def test_packet_loss_never_with_zero_rate(self):
        ch = CommChannel(packet_loss_rate=0.0, seed=0)
        assert all(not ch.is_packet_lost() for _ in range(50))

    def test_packet_loss_always_with_full_rate(self):
        ch = CommChannel(packet_loss_rate=1.0, seed=0)
        assert all(ch.is_packet_lost() for _ in range(20))


# ---------------------------------------------------------------------------
# SatelliteClient
# ---------------------------------------------------------------------------

class TestSatelliteClient:

    def test_repr_contains_id(self):
        c = make_client(cid=3)
        assert "3" in repr(c)

    def test_receive_and_get_update_preserves_shape(self):
        c = make_client()
        global_state = c.model.state_dict()
        c.receive_global_model(global_state)
        state, n, delay = c.get_model_update()
        for k in global_state:
            assert state[k].shape == global_state[k].shape

    def test_local_update_returns_metrics(self):
        c = make_client()
        metrics = c.local_update()
        assert "final_loss" in metrics
        assert "final_acc"  in metrics
        assert "update_norm" in metrics

    def test_local_update_changes_weights(self):
        c = make_client()
        state_before = copy.deepcopy(c.model.state_dict())
        c.local_update()
        state_after = c.model.state_dict()
        changed = False
        for k in state_before:
            if not torch.allclose(state_before[k].float(),
                                   state_after[k].float()):
                changed = True
                break
        assert changed, "Weights did not change after local_update()"

    def test_evaluate_returns_floats(self):
        c = make_client()
        loss, acc = c.evaluate()
        assert isinstance(loss, float)
        assert isinstance(acc,  float)
        assert 0.0 <= acc <= 1.0

    def test_round_losses_logged(self):
        c = make_client()
        c.local_update()
        c.local_update()
        assert len(c.round_losses) == 2

    def test_summary_keys(self):
        c = make_client(cid=5)
        c.local_update()
        s = c.summary()
        assert s["client_id"]   == 5
        assert s["rounds_done"] == 1

    def test_independence_from_global_after_receive(self):
        """Modifying client after receive must not affect the original global state dict."""
        c = make_client()
        global_model = MLP(input_dim=10, hidden_dim=32, num_classes=5)
        state_copy   = copy.deepcopy(global_model.state_dict())
        c.receive_global_model(global_model.state_dict())
        c.local_update()
        # original state_copy should be unchanged
        for k in state_copy:
            assert torch.allclose(state_copy[k].float(),
                                   state_copy[k].float())


# ---------------------------------------------------------------------------
# build_satellite_clients
# ---------------------------------------------------------------------------

class TestBuildSatelliteClients:

    def test_correct_count(self):
        n_feat, n_cls = 10, 5
        loaders = {i: make_loader(n_feat=n_feat, n_classes=n_cls) for i in range(4)}
        counts  = {i: 100 for i in range(4)}
        clients = build_satellite_clients(
            num_clients=4,
            model_factory=lambda: MLP(input_dim=n_feat, hidden_dim=16,
                                       num_classes=n_cls),
            data_loaders=loaders,
            sample_counts=counts,
        )
        assert len(clients) == 4

    def test_unique_client_ids(self):
        n_feat, n_cls = 10, 5
        loaders = {i: make_loader(n_feat=n_feat, n_classes=n_cls) for i in range(6)}
        counts  = {i: 80 for i in range(6)}
        clients = build_satellite_clients(
            num_clients=6,
            model_factory=lambda: MLP(input_dim=n_feat, hidden_dim=16,
                                       num_classes=n_cls),
            data_loaders=loaders,
            sample_counts=counts,
        )
        ids = [c.client_id for c in clients]
        assert len(set(ids)) == 6
