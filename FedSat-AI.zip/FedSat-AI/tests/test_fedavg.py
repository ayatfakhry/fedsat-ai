"""
tests/test_fedavg.py
--------------------
Unit tests for src/fedavg.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import copy
import pytest
import torch
import numpy as np

from src.model  import MLP
from src.fedavg import (
    federated_average,
    federated_average_delta,
    compute_client_weights,
    server_broadcast,
    select_clients,
    compute_update_norm,
)


def make_model(val: float = 0.0) -> MLP:
    m = MLP(input_dim=10, hidden_dim=16, num_classes=4)
    with torch.no_grad():
        for p in m.parameters():
            p.fill_(val)
    return m


class TestFederatedAverage:

    def test_uniform_clients_equal_to_mean(self):
        """Uniform FedAvg of two models with values 1 and 3 should give 2."""
        m_global = make_model(0.0)
        c1 = make_model(1.0)
        c2 = make_model(3.0)
        federated_average(m_global, [c1, c2], client_weights=None)
        for p in m_global.parameters():
            assert torch.allclose(p, torch.full_like(p, 2.0), atol=1e-5)

    def test_weighted_average(self):
        """Weighted FedAvg: weight 0.25 on 0.0, 0.75 on 4.0 → 3.0."""
        m_global = make_model(0.0)
        c1 = make_model(0.0)
        c2 = make_model(4.0)
        federated_average(m_global, [c1, c2], client_weights=[0.25, 0.75])
        for p in m_global.parameters():
            assert torch.allclose(p, torch.full_like(p, 3.0), atol=1e-5)

    def test_single_client(self):
        """With a single client, global should equal that client."""
        m_global = make_model(0.0)
        c1 = make_model(7.0)
        federated_average(m_global, [c1])
        for p in m_global.parameters():
            assert torch.allclose(p, torch.full_like(p, 7.0), atol=1e-5)

    def test_empty_clients_raises(self):
        m = make_model()
        with pytest.raises(ValueError):
            federated_average(m, [])

    def test_preserves_original_clients(self):
        """FedAvg must not modify client models."""
        m_global = make_model(0.0)
        c1 = make_model(2.0)
        c2 = make_model(4.0)
        c1_before = copy.deepcopy(c1.state_dict())
        c2_before = copy.deepcopy(c2.state_dict())
        federated_average(m_global, [c1, c2])
        for k in c1_before:
            assert torch.allclose(c1.state_dict()[k].float(),
                                   c1_before[k].float())
            assert torch.allclose(c2.state_dict()[k].float(),
                                   c2_before[k].float())

    def test_weights_normalisation(self):
        """Un-normalised weights [2, 6] should behave like [0.25, 0.75]."""
        m1 = make_model(0.0)
        m2 = make_model(0.0)
        c1a, c2a = make_model(0.0), make_model(4.0)
        c1b, c2b = make_model(0.0), make_model(4.0)
        federated_average(m1, [c1a, c2a], client_weights=[0.25, 0.75])
        federated_average(m2, [c1b, c2b], client_weights=[2, 6])
        for p1, p2 in zip(m1.parameters(), m2.parameters()):
            assert torch.allclose(p1, p2, atol=1e-5)


class TestFederatedAverageDelta:

    def test_server_lr_1_equals_fedavg(self):
        """With server_lr=1.0, delta variant should equal standard FedAvg."""
        m_global1 = make_model(1.0)
        m_global2 = make_model(1.0)
        clients_a = [make_model(3.0), make_model(5.0)]
        clients_b = [make_model(3.0), make_model(5.0)]
        federated_average(m_global1, clients_a)
        federated_average_delta(m_global2, clients_b, server_lr=1.0)
        for p1, p2 in zip(m_global1.parameters(), m_global2.parameters()):
            assert torch.allclose(p1, p2, atol=1e-4)


class TestComputeClientWeights:

    def test_sums_to_one(self):
        counts = [100, 200, 300, 400]
        weights = compute_client_weights(counts)
        assert abs(sum(weights) - 1.0) < 1e-6

    def test_proportional(self):
        counts  = [1, 3]
        weights = compute_client_weights(counts)
        assert abs(weights[0] - 0.25) < 1e-6
        assert abs(weights[1] - 0.75) < 1e-6

    def test_zero_total_raises(self):
        with pytest.raises(ValueError):
            compute_client_weights([0, 0])


class TestServerBroadcast:

    def test_all_clients_receive_global(self):
        global_m = make_model(9.9)
        clients  = [make_model(0.0) for _ in range(4)]
        server_broadcast(global_m, clients)
        global_state = global_m.state_dict()
        for c in clients:
            for k in global_state:
                assert torch.allclose(c.state_dict()[k].float(),
                                       global_state[k].float())

    def test_independence_after_broadcast(self):
        """Modifying a client after broadcast must not affect global model."""
        global_m = make_model(5.0)
        client   = make_model(0.0)
        server_broadcast(global_m, [client])
        with torch.no_grad():
            for p in client.parameters():
                p.fill_(99.0)
        for p in global_m.parameters():
            assert torch.allclose(p, torch.full_like(p, 5.0), atol=1e-5)


class TestSelectClients:

    def test_correct_count(self):
        rng = np.random.default_rng(0)
        sel = select_clients(10, fraction=0.5, rng=rng)
        assert len(sel) == 5

    def test_within_range(self):
        rng = np.random.default_rng(0)
        sel = select_clients(8, fraction=1.0, rng=rng)
        assert all(0 <= s < 8 for s in sel)

    def test_no_duplicates(self):
        rng = np.random.default_rng(0)
        sel = select_clients(10, fraction=0.8, rng=rng)
        assert len(sel) == len(set(sel))

    def test_at_least_one(self):
        rng = np.random.default_rng(0)
        sel = select_clients(100, fraction=0.001, rng=rng)
        assert len(sel) >= 1


class TestComputeUpdateNorm:

    def test_zero_norm_for_identical_models(self):
        m1 = make_model(3.0)
        m2 = make_model(3.0)
        assert compute_update_norm(m1, m2) < 1e-6

    def test_positive_norm_for_different_models(self):
        m1 = make_model(0.0)
        m2 = make_model(1.0)
        assert compute_update_norm(m1, m2) > 0
