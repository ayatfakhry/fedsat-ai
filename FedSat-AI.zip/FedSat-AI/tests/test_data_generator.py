"""
tests/test_data_generator.py
-----------------------------
Unit tests for src/data_generator.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pytest
import torch
from torch.utils.data import DataLoader

from src.data_generator import (
    generate_synthetic_dataset,
    partition_data_dirichlet,
    partition_data_iid,
    DatasetSplit,
    build_data_loaders,
    compute_class_distribution,
    partition_summary,
)


# ---------------------------------------------------------------------------
# generate_synthetic_dataset
# ---------------------------------------------------------------------------

class TestGenerateSyntheticDataset:

    def test_output_shapes(self):
        X, y = generate_synthetic_dataset(n_samples=200, n_features=10, n_classes=5)
        assert X.shape == (200, 10)
        assert y.shape == (200,)

    def test_output_dtypes(self):
        X, y = generate_synthetic_dataset(n_samples=100, n_features=8, n_classes=4)
        assert X.dtype == np.float32
        assert y.dtype == np.int64

    def test_label_range(self):
        n_classes = 6
        _, y = generate_synthetic_dataset(n_samples=300, n_classes=n_classes)
        assert set(np.unique(y)).issubset(set(range(n_classes)))

    def test_reproducibility(self):
        X1, y1 = generate_synthetic_dataset(n_samples=100, random_state=99)
        X2, y2 = generate_synthetic_dataset(n_samples=100, random_state=99)
        np.testing.assert_array_equal(X1, X2)
        np.testing.assert_array_equal(y1, y2)

    def test_different_seeds_differ(self):
        X1, _ = generate_synthetic_dataset(n_samples=100, random_state=0)
        X2, _ = generate_synthetic_dataset(n_samples=100, random_state=1)
        assert not np.allclose(X1, X2)

    def test_save_to_csv(self, tmp_path):
        import pandas as pd
        path = str(tmp_path / "test.csv")
        X, y = generate_synthetic_dataset(n_samples=50, n_features=5,
                                           n_classes=3, save_path=path)
        df = pd.read_csv(path)
        assert len(df) == 50
        assert "label" in df.columns


# ---------------------------------------------------------------------------
# partition_data_dirichlet
# ---------------------------------------------------------------------------

class TestPartitionDataDirichlet:

    def setup_method(self):
        _, self.y = generate_synthetic_dataset(n_samples=1000, n_classes=5)

    def test_all_indices_covered(self):
        parts = partition_data_dirichlet(self.y, num_clients=5, alpha=0.5)
        all_idx = sorted([i for idx in parts.values() for i in idx])
        assert all_idx == list(range(len(self.y)))

    def test_correct_number_of_clients(self):
        parts = partition_data_dirichlet(self.y, num_clients=8, alpha=1.0)
        assert len(parts) == 8

    def test_no_empty_client(self):
        parts = partition_data_dirichlet(self.y, num_clients=5, alpha=0.5,
                                         min_samples=5)
        for cid, idx in parts.items():
            assert len(idx) >= 5, f"Client {cid} has {len(idx)} samples"

    def test_non_iid_low_alpha(self):
        # With very low alpha, class distribution should be very uneven
        parts = partition_data_dirichlet(self.y, num_clients=5, alpha=0.01)
        dist  = compute_class_distribution(parts, self.y, num_classes=5)
        # At least one client should have >70% of samples from one class
        proportions = dist / dist.sum(axis=1, keepdims=True)
        max_per_client = proportions.max(axis=1)
        assert max_per_client.max() > 0.5

    def test_reproducibility(self):
        p1 = partition_data_dirichlet(self.y, 4, alpha=0.5, random_state=7)
        p2 = partition_data_dirichlet(self.y, 4, alpha=0.5, random_state=7)
        for cid in p1:
            assert sorted(p1[cid]) == sorted(p2[cid])


# ---------------------------------------------------------------------------
# partition_data_iid
# ---------------------------------------------------------------------------

class TestPartitionDataIID:

    def setup_method(self):
        _, self.y = generate_synthetic_dataset(n_samples=500, n_classes=5)

    def test_all_indices_covered(self):
        parts = partition_data_iid(self.y, num_clients=5)
        all_idx = sorted([i for idx in parts.values() for i in idx])
        assert all_idx == list(range(len(self.y)))

    def test_roughly_equal_sizes(self):
        K = 5
        parts = partition_data_iid(self.y, num_clients=K)
        sizes = [len(v) for v in parts.values()]
        assert max(sizes) - min(sizes) <= 1


# ---------------------------------------------------------------------------
# DatasetSplit
# ---------------------------------------------------------------------------

class TestDatasetSplit:

    def test_len(self):
        X = np.random.randn(100, 10).astype(np.float32)
        y = np.random.randint(0, 5, 100).astype(np.int64)
        ds = DatasetSplit(X, y, list(range(0, 30)))
        assert len(ds) == 30

    def test_getitem_types(self):
        X = np.random.randn(50, 8).astype(np.float32)
        y = np.random.randint(0, 3, 50).astype(np.int64)
        ds = DatasetSplit(X, y, list(range(10)))
        x_item, y_item = ds[0]
        assert isinstance(x_item, torch.Tensor)
        assert isinstance(y_item, torch.Tensor)
        assert x_item.shape == (8,)


# ---------------------------------------------------------------------------
# build_data_loaders
# ---------------------------------------------------------------------------

class TestBuildDataLoaders:

    def test_returns_loaders(self):
        X = np.random.randn(200, 10).astype(np.float32)
        y = np.random.randint(0, 5, 200).astype(np.int64)
        parts = partition_data_iid(y, num_clients=4)
        loaders = build_data_loaders(X, y, parts, batch_size=16)
        assert len(loaders) == 4
        for cid, loader in loaders.items():
            assert isinstance(loader, DataLoader)

    def test_batches_correct_shape(self):
        X = np.random.randn(200, 12).astype(np.float32)
        y = np.random.randint(0, 4, 200).astype(np.int64)
        parts = partition_data_iid(y, num_clients=2)
        loaders = build_data_loaders(X, y, parts, batch_size=8)
        for batch_X, batch_y in loaders[0]:
            assert batch_X.shape[-1] == 12
            break


# ---------------------------------------------------------------------------
# compute_class_distribution
# ---------------------------------------------------------------------------

class TestComputeClassDistribution:

    def test_shape(self):
        y = np.array([0,1,2,0,1,2,0,1,2,2])
        parts = {0: [0,3,6], 1: [1,4,7], 2: [2,5,8,9]}
        dist = compute_class_distribution(parts, y, num_classes=3)
        assert dist.shape == (3, 3)

    def test_total_count(self):
        _, y = generate_synthetic_dataset(n_samples=300, n_classes=5)
        parts = partition_data_iid(y, num_clients=3)
        dist  = compute_class_distribution(parts, y, num_classes=5)
        assert dist.sum() == 300
